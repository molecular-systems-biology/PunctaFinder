You can create the punctafinder_env environment by importing environment.yml in conda:
conda env create -f environment.yml

conda activate punctafinder_env
python test.py
